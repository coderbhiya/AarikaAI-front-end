"use client";

import React from "react";
import { LoginPage } from "@/components/auth/LoginPage";

export default function Auth() {
  return <LoginPage />;
}
